export GOPATH="/home/tomcat/go_path"
export GOROOT="/home/tomcat/go"
export PATH=$GOROOT/bin:$PATH
go run main.go >> /opt/ipify/logs/ipify.log 2>&1 &
