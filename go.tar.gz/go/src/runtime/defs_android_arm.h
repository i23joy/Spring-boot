// TODO: Generate using cgo like defs_linux_{386,amd64}.h

#include "defs_linux_arm.h"
